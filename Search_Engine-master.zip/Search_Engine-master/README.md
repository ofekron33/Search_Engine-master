# Search_Engine
The is a skeleton of a search engine project for your convenience.
Please follow the instructions provided in the file: intructions.txt
