class GUI:
    pass
